import { FaHeart, FaRegHeart } from "react-icons/fa6";

import { Container, Content, Background, Layer } from './styles';

import { Header } from '../../components/Header';
import { Table } from '../../components/Table';

export function Comparison() {
    const options = [
        {id: 1, name: 'Celta'},
        {id: 2, name: 'Corsa'}
    ];

    const image = {
        VehImg: 'http://localhost/projeto/backend/public/media/vehicle/49b96350a56bb96caa0e3f97a7b9dca8.png',
        VehName: 'Corsa'
    }

    return (
        <Container>
            <Header />

            <Background>
                <Layer>
                    <Content>
                        <div>
                            <h2>Comparação</h2>
                            <FaRegHeart />
                        </div>

                        <main>
                            <Table title="Celta" img={image} />
                            <Table list={options} img={image} />
                            <Table list={options} img={image} />
                            <Table list={options} img={image} />
                        </main>
                    </Content>
                </Layer>
            </Background>
        </Container>
    )
}